fx_version 'cerulean'
game 'gta5'

name 'PacketAlert'
author '3ro.re'
description 'Readme'
version '1.1.0'

client_script 'client.lua'
server_script 'server.lua'

dependency '/assetpacks'